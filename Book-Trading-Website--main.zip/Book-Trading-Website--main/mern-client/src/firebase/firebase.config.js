// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDFM2vYfKfRL3f2mXcpUi_sInCcmhRO9EE",
  authDomain: "mern-book-inventory-4099e.firebaseapp.com",
  projectId: "mern-book-inventory-4099e",
  storageBucket: "mern-book-inventory-4099e.appspot.com",
  messagingSenderId: "50100602679",
  appId: "1:50100602679:web:c12c0a3af2aa3d6cc87cb2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;